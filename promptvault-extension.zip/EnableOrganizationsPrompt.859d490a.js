var e,r;"function"==typeof(e=globalThis.define)&&(r=e,e=null),function(r,t,n,s,i){var o="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},a="function"==typeof o[s]&&o[s],l=a.cache||{},c="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function d(e,t){if(!l[e]){if(!r[e]){var n="function"==typeof o[s]&&o[s];if(!t&&n)return n(e,!0);if(a)return a(e,!0);if(c&&"string"==typeof e)return c(e);var i=Error("Cannot find module '"+e+"'");throw i.code="MODULE_NOT_FOUND",i}u.resolve=function(t){var n=r[e][1][t];return null!=n?n:t},u.cache={};var p=l[e]=new d.Module(e);r[e][0].call(p.exports,u,p,p.exports,this)}return l[e].exports;function u(e){var r=u.resolve(e);return!1===r?{}:d(r)}}d.isParcelRequire=!0,d.Module=function(e){this.id=e,this.bundle=d,this.exports={}},d.modules=r,d.cache=l,d.parent=a,d.register=function(e,t){r[e]=[function(e,r){r.exports=t},{}]},Object.defineProperty(d,"root",{get:function(){return o[s]}}),o[s]=d;for(var p=0;p<t.length;p++)d(t[p]);if(n){var u=d(n);"object"==typeof exports&&"undefined"!=typeof module?module.exports=u:"function"==typeof e&&e.amd?e(function(){return u}):i&&(this[i]=u)}}({iNuVz:[function(e,r,t){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(t),n.export(t,"EnableOrganizationsPrompt",()=>m);var s=e("../../../contexts/EnvironmentContext.js"),i=e("../../../styledSystem/InternalThemeProvider.js"),o=e("../../../customizables/index.js"),a=e("../../../elements/Modal.js"),l=e("../../../elements/Portal.js"),c=e("../shared.js"),d=e("react"),p=n.interopDefault(d),u=e("@clerk/shared/react"),h=e("@emotion/react/jsx-runtime"),x=e("@emotion/react");let f=({caller:e,onSuccess:r,onClose:t})=>{let n=(0,u.useClerk)(),[i,p]=(0,d.useState)(!1),[f,m]=(0,d.useState)(!1),[g,b]=(0,d.useState)(null),[w,y]=(0,d.useState)(!1),z=(0,d.useRef)(null),k=(0,s.useEnvironment)(),P=(0,d.useId)(),B=!e.startsWith("use"),_=void 0!==k?.organizationSettings.forceOrganizationSelection;return(0,h.jsx)(l.Portal,{children:(0,h.jsx)(a.Modal,{canCloseModal:!1,containerSx:()=>({alignItems:"center"}),initialFocusRef:z,children:(0,h.jsxs)(c.PromptContainer,{sx:()=>({display:"flex",flexDirection:"column",width:"30rem",maxWidth:"calc(100vw - 2rem)"}),children:[(0,h.jsxs)(o.Flex,{direction:"col",sx:e=>({padding:`${e.sizes.$4} ${e.sizes.$6}`,paddingBottom:e.sizes.$4,gap:e.sizes.$2}),children:[(0,h.jsxs)(o.Flex,{as:"header",align:"center",sx:e=>({gap:e.sizes.$2}),children:[(0,h.jsx)(E,{isEnabled:f}),(0,h.jsx)("h1",{css:[c.basePromptElementStyles,(0,x.css)`
                    color: white;
                    font-size: 0.875rem;
                    font-weight: 500;
                    outline: none;
                  `],tabIndex:-1,ref:z,children:f?"Organizations feature enabled":"Organizations feature required"})]}),(0,h.jsx)(o.Flex,{direction:"col",align:"start",sx:e=>({gap:e.sizes.$0x5}),children:f?(0,h.jsxs)("p",{css:[c.basePromptElementStyles,(0,x.css)`
                      color: #b4b4b4;
                      font-size: 0.8125rem;
                      font-weight: 400;
                      line-height: 1.3;
                    `],children:[n.user&&g?`The Organizations feature has been enabled for your application. A default organization named "${g}" was created automatically. You can manage or rename it in your`:"The Organizations feature has been enabled for your application. You can manage it in your"," ",(0,h.jsx)($,{href:"https://dashboard.clerk.com/~/organizations-settings",target:"_blank",rel:"noopener noreferrer",children:"dashboard"}),"."]}):(0,h.jsxs)(h.Fragment,{children:[(0,h.jsxs)("p",{id:P,css:[c.basePromptElementStyles,(0,x.css)`
                        color: #b4b4b4;
                        font-size: 0.8125rem;
                        font-weight: 400;
                        line-height: 1.23;
                      `],children:["Enable Organizations to use"," ",(0,h.jsx)("code",{css:[c.basePromptElementStyles,(0,x.css)`
                          font-size: 0.75rem;
                          color: white;
                          font-family: monospace;
                          line-height: 1.23;
                        `],children:B?`<${e} />`:e})," "]}),(0,h.jsx)($,{href:"https://clerk.com/docs/guides/organizations/overview",target:"_blank",rel:"noopener noreferrer",children:"Learn more"})]})}),_&&!f&&(0,h.jsx)(o.Flex,{sx:e=>({marginTop:e.sizes.$2}),direction:"col",children:(0,h.jsxs)(v,{value:w?"optional":"required",onChange:e=>y("optional"===e),labelledBy:P,children:[(0,h.jsx)(S,{value:"required",label:(0,h.jsxs)(o.Flex,{wrap:"wrap",sx:e=>({columnGap:e.sizes.$2,rowGap:e.sizes.$1}),children:[(0,h.jsx)("span",{children:"Membership required"}),(0,h.jsx)(C,{children:"Standard"})]}),description:(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)("span",{className:"block",children:"Users need to belong to at least one organization."}),(0,h.jsx)("span",{children:"Common for most B2B SaaS applications"})]})}),(0,h.jsx)(S,{value:"optional",label:"Membership optional",description:"Users can work outside of an organization with a personal account"})]})})]}),(0,h.jsx)("span",{css:(0,x.css)`
              height: 1px;
              display: block;
              width: calc(100% - 2px);
              margin-inline: auto;
              background-color: #151515;
              box-shadow: 0px 1px 0px 0px #424242;
            `}),(0,h.jsx)(o.Flex,{justify:"center",sx:e=>({padding:`${e.sizes.$4} ${e.sizes.$6}`,gap:e.sizes.$3,justifyContent:"flex-end"}),children:f?(0,h.jsx)(j,{variant:"solid",onClick:()=>{n.user?r?.():(n.redirectToSignIn(),n.__internal_closeEnableOrganizationsPrompt?.())},children:n.user?"Continue":"Sign in to continue"}):(0,h.jsxs)(h.Fragment,{children:[(0,h.jsx)(j,{variant:"outline",onClick:()=>{n?.__internal_closeEnableOrganizationsPrompt?.(),t?.()},children:"I'll remove it myself"}),(0,h.jsx)(j,{variant:"solid",onClick:()=>{p(!0);let e={enable_organizations:!0};_&&(e.organization_allow_personal_accounts=w),k.__internal_enableEnvironmentSetting(e).then(async()=>{b((await n.user?.getOrganizationMemberships())?.data[0]?.organization.name??null),m(!0),p(!1)}).catch(()=>{p(!1)})},disabled:i,children:"Enable Organizations"})]})})]})})})},m=e=>(0,h.jsx)(i.InternalThemeProvider,{children:(0,h.jsx)(f,{...e})}),g=(0,x.css)`
  ${c.basePromptElementStyles};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 1.75rem;
  padding: 0.375rem 0.625rem;
  border-radius: 0.375rem;
  font-size: 0.75rem;
  font-weight: 500;
  letter-spacing: 0.12px;
  color: white;
  text-shadow: 0px 1px 2px rgba(0, 0, 0, 0.32);
  white-space: nowrap;
  user-select: none;
  color: white;
  outline: none;

  &:not(:disabled) {
    transition: 120ms ease-in-out;
    transition-property: background-color, border-color, box-shadow, color;
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  &:focus-visible:not(:disabled) {
    outline: 2px solid white;
    outline-offset: 2px;
  }
`,b={solid:(0,x.css)`
  background: linear-gradient(180deg, rgba(0, 0, 0, 0) 30.5%, rgba(0, 0, 0, 0.05) 100%), #454545;
  box-shadow:
    0 0 3px 0 rgba(253, 224, 71, 0) inset,
    0 0 0 1px rgba(255, 255, 255, 0.04) inset,
    0 1px 0 0 rgba(255, 255, 255, 0.04) inset,
    0 0 0 1px rgba(0, 0, 0, 0.12),
    0 1.5px 2px 0 rgba(0, 0, 0, 0.48);

  &:hover:not(:disabled) {
    background: linear-gradient(180deg, rgba(0, 0, 0, 0) 30.5%, rgba(0, 0, 0, 0.15) 100%), #5f5f5f;
    box-shadow:
      0 0 3px 0 rgba(253, 224, 71, 0) inset,
      0 0 0 1px rgba(255, 255, 255, 0.04) inset,
      0 1px 0 0 rgba(255, 255, 255, 0.04) inset,
      0 0 0 1px rgba(0, 0, 0, 0.12),
      0 1.5px 2px 0 rgba(0, 0, 0, 0.48);
  }
`,outline:(0,x.css)`
  border: 1px solid rgba(118, 118, 132, 0.25);
  background: rgba(69, 69, 69, 0.1);

  &:hover:not(:disabled) {
    border-color: rgba(118, 118, 132, 0.5);
  }
`},j=(0,d.forwardRef)(({variant:e="solid",...r},t)=>(0,h.jsx)("button",{ref:t,type:"button",css:[g,b[e]],...r})),C=({children:e})=>(0,h.jsx)("span",{css:(0,x.css)`
        ${c.basePromptElementStyles};
        display: inline-flex;
        align-items: center;
        padding: 0.125rem 0.375rem;
        border-radius: 0.25rem;
        font-size: 0.6875rem;
        font-weight: 500;
        line-height: 1.23;
        background-color: #ebebeb;
        color: #2b2b34;
        white-space: nowrap;
      `,children:e}),[w,y]=(0,u.createContextAndHook)("RadioGroupContext"),v=({value:e,onChange:r,children:t,labelledBy:n})=>{let s=(0,d.useId)(),i=(0,p.default).useMemo(()=>({value:{name:s,value:e,onChange:r}}),[s,e,r]);return(0,h.jsx)(w.Provider,{value:i,children:(0,h.jsx)(o.Flex,{role:"radiogroup",direction:"col",gap:3,"aria-orientation":"vertical","aria-labelledby":n,children:t})})},z="1rem",k="0.5rem",S=({value:e,label:r,description:t})=>{let{name:n,value:s,onChange:i}=y(),a=(0,d.useId)(),l=e===s;return(0,h.jsxs)(o.Flex,{direction:"col",gap:1,children:[(0,h.jsxs)("label",{css:(0,x.css)`
          ${c.basePromptElementStyles};
          display: flex;
          align-items: flex-start;
          gap: ${k};
          cursor: pointer;
          user-select: none;

          &:has(input:focus-visible) > span:first-of-type {
            outline: 2px solid white;
            outline-offset: 2px;
          }

          &:hover:has(input:not(:checked)) > span:first-of-type {
            background-color: rgba(255, 255, 255, 0.08);
          }

          &:hover:has(input:checked) > span:first-of-type {
            background-color: rgba(108, 71, 255, 0.8);
            background-color: color-mix(in srgb, #6c47ff 80%, transparent);
          }
        `,children:[(0,h.jsx)("input",{type:"radio",name:n,value:e,checked:l,onChange:()=>i(e),"aria-describedby":t?a:void 0,css:(0,x.css)`
            ${c.basePromptElementStyles};
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border-width: 0;
          `}),(0,h.jsx)("span",{"aria-hidden":"true",css:(0,x.css)`
            ${c.basePromptElementStyles};
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: ${z};
            height: ${z};
            margin-top: 0.125rem;
            flex-shrink: 0;
            border-radius: 50%;
            border: 1px solid rgba(255, 255, 255, 0.3);
            background-color: transparent;
            transition: 120ms ease-in-out;
            transition-property: border-color, background-color, box-shadow;

            ${l&&(0,x.css)`
              border-width: 2px;
              border-color: #6c47ff;
              background-color: #6c47ff;
              background-color: color-mix(in srgb, #6c47ff 100%, transparent);
              box-shadow: 0 0 0 2px rgba(108, 71, 255, 0.2);
            `}

            &::after {
              content: '';
              position: absolute;
              width: 0.375rem;
              height: 0.375rem;
              border-radius: 50%;
              background-color: white;
              opacity: ${l?1:0};
              transform: scale(${l?1:0});
              transition: 120ms ease-in-out;
              transition-property: opacity, transform;
            }
          `}),(0,h.jsx)("span",{css:[c.basePromptElementStyles,(0,x.css)`
              font-size: 0.875rem;
              font-weight: 500;
              line-height: 1.25;
              color: white;
            `],children:r})]}),t&&(0,h.jsx)("span",{id:a,css:[c.basePromptElementStyles,(0,x.css)`
              padding-inline-start: calc(${z} + ${k});
              font-size: 0.75rem;
              line-height: 1.33;
              color: #c3c3c6;
              text-wrap: pretty;
            `],children:t})]})},$=(0,d.forwardRef)(({children:e,css:r,...t},n)=>(0,h.jsx)("a",{ref:n,...t,css:[c.basePromptElementStyles,(0,x.css)`
            color: #a8a8ff;
            font-size: inherit;
            font-weight: 500;
            line-height: 1.3;
            font-size: 0.8125rem;
            min-width: 0;
          `,r],children:e})),E=({isEnabled:e})=>{let[r,t]=(0,d.useState)(0);(0,d.useLayoutEffect)(()=>{if(e){t(e=>0===e?180:0);return}let r=setInterval(()=>{t(e=>0===e?180:0)},2e3);return()=>clearInterval(r)},[e]);let n="idle",s="warning";e&&(0===r?(n="success",s="warning"):(s="success",n="idle"));let i=e=>{switch(e){case"idle":return(0,h.jsx)(c.ClerkLogoIcon,{});case"success":return(0,h.jsx)(c.PromptSuccessIcon,{css:(0,x.css)`
              width: 1.25rem;
              height: 1.25rem;
            `});case"warning":return(0,h.jsxs)("svg",{css:(0,x.css)`
              width: 1.25rem;
              height: 1.25rem;
            `,viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:[(0,h.jsx)("path",{opacity:"0.2",d:"M17.25 10C17.25 14.0041 14.0041 17.25 10 17.25C5.99594 17.25 2.75 14.0041 2.75 10C2.75 5.99594 5.99594 2.75 10 2.75C14.0041 2.75 17.25 5.99594 17.25 10Z",fill:"#EAB308"}),(0,h.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 3.5C6.41015 3.5 3.5 6.41015 3.5 10C3.5 13.5899 6.41015 16.5 10 16.5C13.5899 16.5 16.5 13.5899 16.5 10C16.5 6.41015 13.5899 3.5 10 3.5ZM2 10C2 5.58172 5.58172 2 10 2C14.4183 2 18 5.58172 18 10C18 14.4183 14.4183 18 10 18C5.58172 18 2 14.4183 2 10Z",fill:"#EAB308"}),(0,h.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 6C10.5523 6 11 6.44772 11 7V9C11 9.55228 10.5523 10 10 10C9.44772 10 9 9.55228 9 9V7C9 6.44772 9.44772 6 10 6Z",fill:"#EAB308"}),(0,h.jsx)("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M10 12C10.5523 12 11 12.4477 11 13V13.01C11 13.5623 10.5523 14.01 10 14.01C9.44772 14.01 9 13.5623 9 13.01V13C9 12.4477 9.44772 12 10 12Z",fill:"#EAB308"})]})}};return(0,h.jsx)("div",{css:(0,x.css)`
        perspective: 1000px;
        width: 1.25rem;
        height: 1.25rem;
      `,children:(0,h.jsxs)("div",{css:(0,x.css)`
          position: relative;
          width: 100%;
          height: 100%;
          transform-style: preserve-3d;
          transition: transform 0.6s ease-in-out;
          transform: rotateY(${r}deg);

          @media (prefers-reduced-motion: reduce) {
            transition: none;
          }
        `,children:[(0,h.jsx)("span",{"aria-hidden":!0,css:(0,x.css)`
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            -webkit-font-smoothing: antialiased;
            transform: rotateY(0deg);
          `,children:i(n)}),(0,h.jsx)("span",{"aria-hidden":!0,css:(0,x.css)`
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            transform: rotateY(180deg);
            display: flex;
            align-items: center;
            justify-content: center;
            -webkit-font-smoothing: antialiased;
          `,children:i(s)})]})})}},{"../../../contexts/EnvironmentContext.js":"eQ6Zj","../../../styledSystem/InternalThemeProvider.js":"aiZZR","../../../customizables/index.js":"4yGSI","../../../elements/Modal.js":"4Rzwv","../../../elements/Portal.js":"jRWrx","../shared.js":"2JCj5",react:"a8qhJ","@clerk/shared/react":"hObst","@emotion/react/jsx-runtime":"1XNeT","@emotion/react":"aNgYj","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],jRWrx:[function(e,r,t){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(t),n.export(t,"Portal",()=>a);var s=e("react"),i=n.interopDefault(s),o=e("react-dom");let a=e=>{let r=(0,i.default).useRef(document.createElement("div"));return(0,i.default).useEffect(()=>(document.body.appendChild(r.current),()=>{document.body.removeChild(r.current)}),[]),(0,o.createPortal)(e.children,r.current)}},{react:"a8qhJ","react-dom":"8sy1S","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"2JCj5":[function(e,r,t){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(t),n.export(t,"ClerkLogoIcon",()=>p),n.export(t,"PromptContainer",()=>a),n.export(t,"PromptSuccessIcon",()=>c),n.export(t,"basePromptElementStyles",()=>l),n.export(t,"handleDashboardUrlParsing",()=>d);var s=e("../../customizables/index.js"),i=e("@emotion/react/jsx-runtime"),o=e("@emotion/react");function a({children:e,sx:r,...t}){return(0,i.jsx)(s.Flex,{sx:e=>[{borderRadius:"1.25rem",fontFamily:e.fonts.$main,background:"linear-gradient(180deg, rgba(255, 255, 255, 0.16) 0%, rgba(255, 255, 255, 0) 100%), #1f1f1f",boxShadow:"0px 0px 0px 0.5px #2F3037 inset, 0px 1px 0px 0px rgba(255, 255, 255, 0.08) inset, 0px 0px 0.8px 0.8px rgba(255, 255, 255, 0.20) inset, 0px 0px 0px 0px rgba(255, 255, 255, 0.72), 0px 16px 36px -6px rgba(0, 0, 0, 0.36), 0px 6px 16px -2px rgba(0, 0, 0, 0.20);"},r],...t,children:e})}let l=(0,o.css)`
  box-sizing: border-box;
  padding: 0;
  margin: 0;
  background: none;
  border: none;
  line-height: 1.5;
  font-family:
    -apple-system,
    BlinkMacSystemFont,
    avenir next,
    avenir,
    segoe ui,
    helvetica neue,
    helvetica,
    Cantarell,
    Ubuntu,
    roboto,
    noto,
    arial,
    sans-serif;
  text-decoration: none;
`;function c(e){return(0,i.jsx)("svg",{...e,viewBox:"0 0 16 17",fill:"none","aria-hidden":!0,xmlns:"http://www.w3.org/2000/svg",children:(0,i.jsxs)("g",{opacity:"0.88",children:[(0,i.jsx)("path",{d:"M13.8002 8.20039C13.8002 8.96206 13.6502 9.71627 13.3587 10.42C13.0672 11.1236 12.64 11.763 12.1014 12.3016C11.5628 12.8402 10.9234 13.2674 10.2198 13.5589C9.51607 13.8504 8.76186 14.0004 8.0002 14.0004C7.23853 14.0004 6.48432 13.8504 5.78063 13.5589C5.07694 13.2674 4.43756 12.8402 3.89898 12.3016C3.3604 11.763 2.93317 11.1236 2.64169 10.42C2.35022 9.71627 2.2002 8.96206 2.2002 8.20039C2.2002 6.66214 2.81126 5.18688 3.89898 4.09917C4.98669 3.01146 6.46194 2.40039 8.0002 2.40039C9.53845 2.40039 11.0137 3.01146 12.1014 4.09917C13.1891 5.18688 13.8002 6.66214 13.8002 8.20039Z",fill:"#22C543",fillOpacity:"0.16"}),(0,i.jsx)("path",{d:"M6.06686 8.68372L7.51686 10.1337L9.93353 6.75039M13.8002 8.20039C13.8002 8.96206 13.6502 9.71627 13.3587 10.42C13.0672 11.1236 12.64 11.763 12.1014 12.3016C11.5628 12.8402 10.9234 13.2674 10.2198 13.5589C9.51607 13.8504 8.76186 14.0004 8.0002 14.0004C7.23853 14.0004 6.48432 13.8504 5.78063 13.5589C5.07694 13.2674 4.43756 12.8402 3.89898 12.3016C3.3604 11.763 2.93317 11.1236 2.64169 10.42C2.35022 9.71627 2.2002 8.96206 2.2002 8.20039C2.2002 6.66214 2.81126 5.18688 3.89898 4.09917C4.98669 3.01146 6.46194 2.40039 8.0002 2.40039C9.53845 2.40039 11.0137 3.01146 12.1014 4.09917C13.1891 5.18688 13.8002 6.66214 13.8002 8.20039Z",stroke:"#22C543",strokeWidth:"1.2",strokeLinecap:"round",strokeLinejoin:"round"})]})})}function d(e){let r=new URL(e).href.match(/^https?:\/\/(.*?)\/apps\/app_(.+?)\/instances\/ins_(.+?)(?:\/.*)?$/);if(!r)throw Error("Invalid value Dashboard URL structure");return{baseDomain:`https://${r[1]}`,appId:`app_${r[2]}`,instanceId:`ins_${r[3]}`}}function p(){return(0,i.jsxs)("svg",{width:"1rem",height:"1.25rem",viewBox:"0 0 16 20",fill:"none","aria-hidden":!0,xmlns:"http://www.w3.org/2000/svg",children:[(0,i.jsxs)("g",{filter:"url(#filter0_i_438_501)",children:[(0,i.jsx)("path",{d:"M10.4766 9.99979C10.4766 11.3774 9.35978 12.4942 7.98215 12.4942C6.60452 12.4942 5.48773 11.3774 5.48773 9.99979C5.48773 8.62216 6.60452 7.50537 7.98215 7.50537C9.35978 7.50537 10.4766 8.62216 10.4766 9.99979Z",fill:"#BBBBBB"}),(0,i.jsx)("path",{d:"M12.4176 3.36236C12.6676 3.52972 12.6889 3.88187 12.4762 4.09457L10.6548 5.91595C10.4897 6.08107 10.2336 6.10714 10.0257 6.00071C9.41273 5.68684 8.71811 5.50976 7.98214 5.50976C5.5024 5.50976 3.49219 7.51998 3.49219 9.99972C3.49219 10.7357 3.66926 11.4303 3.98314 12.0433C4.08957 12.2511 4.06349 12.5073 3.89837 12.6724L2.07699 14.4938C1.86429 14.7065 1.51215 14.6851 1.34479 14.4352C0.495381 13.1666 0 11.641 0 9.99972C0 5.5913 3.57373 2.01758 7.98214 2.01758C9.62345 2.01758 11.1491 2.51296 12.4176 3.36236Z",fill:"#8F8F8F"}),(0,i.jsx)("path",{d:"M12.4762 15.905C12.6889 16.1177 12.6675 16.4698 12.4176 16.6372C11.149 17.4866 9.62342 17.982 7.9821 17.982C6.34078 17.982 4.81516 17.4866 3.54661 16.6372C3.29666 16.4698 3.27531 16.1177 3.48801 15.905L5.30938 14.0836C5.4745 13.9185 5.73066 13.8924 5.93851 13.9988C6.55149 14.3127 7.24612 14.4898 7.9821 14.4898C8.71808 14.4898 9.4127 14.3127 10.0257 13.9988C10.2335 13.8924 10.4897 13.9185 10.6548 14.0836L12.4762 15.905Z",fill:"#BBBBBB"})]}),(0,i.jsx)("defs",{children:(0,i.jsxs)("filter",{id:"filter0_i_438_501",x:"0",y:"1.86758",width:"12.6217",height:"16.1144",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB",children:[(0,i.jsx)("feFlood",{floodOpacity:"0",result:"BackgroundImageFix"}),(0,i.jsx)("feBlend",{mode:"normal",in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),(0,i.jsx)("feColorMatrix",{in:"SourceAlpha",type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"hardAlpha"}),(0,i.jsx)("feOffset",{dy:"-0.15"}),(0,i.jsx)("feGaussianBlur",{stdDeviation:"0.15"}),(0,i.jsx)("feComposite",{in2:"hardAlpha",operator:"arithmetic",k2:"-1",k3:"1"}),(0,i.jsx)("feColorMatrix",{type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"}),(0,i.jsx)("feBlend",{mode:"normal",in2:"shape",result:"effect1_innerShadow_438_501"})]})})]})}},{"../../customizables/index.js":"4yGSI","@emotion/react/jsx-runtime":"1XNeT","@emotion/react":"aNgYj","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}]},[],null,"parcelRequire56c9"),globalThis.define=r;