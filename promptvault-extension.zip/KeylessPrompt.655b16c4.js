var e,t;"function"==typeof(e=globalThis.define)&&(t=e,e=null),function(t,r,n,i,o){var s="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:{},a="function"==typeof s[i]&&s[i],l=a.cache||{},c="undefined"!=typeof module&&"function"==typeof module.require&&module.require.bind(module);function u(e,r){if(!l[e]){if(!t[e]){var n="function"==typeof s[i]&&s[i];if(!r&&n)return n(e,!0);if(a)return a(e,!0);if(c&&"string"==typeof e)return c(e);var o=Error("Cannot find module '"+e+"'");throw o.code="MODULE_NOT_FOUND",o}p.resolve=function(r){var n=t[e][1][r];return null!=n?n:r},p.cache={};var d=l[e]=new u.Module(e);t[e][0].call(d.exports,p,d,d.exports,this)}return l[e].exports;function p(e){var t=p.resolve(e);return!1===t?{}:u(t)}}u.isParcelRequire=!0,u.Module=function(e){this.id=e,this.bundle=u,this.exports={}},u.modules=t,u.cache=l,u.parent=a,u.register=function(e,r){t[e]=[function(e,t){t.exports=r},{}]},Object.defineProperty(u,"root",{get:function(){return s[i]}}),s[i]=u;for(var d=0;d<r.length;d++)u(r[d]);if(n){var p=u(n);"object"==typeof exports&&"undefined"!=typeof module?module.exports=p:"function"==typeof e&&e.amd?e(function(){return p}):o&&(this[o]=p)}}({g6rVs:[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"KeylessPrompt",()=>w),n.export(r,"getCurrentState",()=>b),n.export(r,"getResolvedContent",()=>y);var i=e("../../../styledSystem/InternalThemeProvider.js"),o=e("../shared.js"),s=e("./use-drag-to-corner.js"),a=e("./use-revalidate-environment.js"),l=e("react"),c=e("@clerk/shared/react"),u=e("@emotion/react/jsx-runtime"),d=e("@emotion/react");let p="18rem",f="cubic-bezier(0.2, 0, 0, 1)",h=(0,d.css)`
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  background: none;
  border: none;
  font-family:
    -apple-system,
    BlinkMacSystemFont,
    avenir next,
    avenir,
    segoe ui,
    helvetica neue,
    helvetica,
    Cantarell,
    Ubuntu,
    roboto,
    noto,
    arial,
    sans-serif;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  text-decoration: none;
  color: inherit;
  appearance: none;
`;function m(e){return e?"220ms":"180ms"}let x=(0,d.css)`
  ${h};
  margin: 0.75rem 0 0;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 1.75rem;
  padding: 0.25rem 0.625rem;
  border-radius: 0.375rem;
  font-size: 0.75rem;
  font-weight: 500;
  letter-spacing: 0.12px;
  color: #fde047;
  text-shadow: 0px 1px 2px rgba(0, 0, 0, 0.32);
  white-space: nowrap;
  user-select: none;
  cursor: pointer;
  background: linear-gradient(180deg, rgba(0, 0, 0, 0) 30.5%, rgba(0, 0, 0, 0.05) 100%), #454545;
  box-shadow:
    0px 0px 0px 1px rgba(255, 255, 255, 0.04) inset,
    0px 1px 0px 0px rgba(255, 255, 255, 0.04) inset,
    0px 0px 0px 1px rgba(0, 0, 0, 0.12),
    0px 1.5px 2px 0px rgba(0, 0, 0, 0.48),
    0px 0px 4px 0px rgba(243, 107, 22, 0) inset;
  outline: none;
  &:hover {
    background: #4b4b4b;
    transition: background-color 120ms ease-in-out;

    @media (prefers-reduced-motion: reduce) {
      transition: none;
    }
  }
  &:focus-visible {
    outline: 2px solid #6c47ff;
    outline-offset: 2px;
  }
`,g={idle:{triggerWidth:"14.25rem",title:"Configure your application",description:(0,u.jsxs)(u.Fragment,{children:[(0,u.jsx)("p",{children:"Temporary API keys are enabled so you can get started immediately."}),(0,u.jsx)("ul",{children:["Add SSO connections (eg. GitHub)","Set up B2B authentication","Enable MFA"].map(e=>(0,u.jsx)("li",{children:e},e))}),(0,u.jsx)("p",{children:"Access the dashboard to customize auth settings and explore Clerk features."})]}),cta:{kind:"link",text:"Configure your application",href:({claimUrl:e})=>e}},userCreated:{triggerWidth:"15.75rem",title:"You've created your first user!",description:(0,u.jsx)("p",{children:"Head to the dashboard to customize authentication settings, view user info, and explore more features."}),cta:{kind:"link",text:"Configure your application",href:({claimUrl:e})=>e}},claimed:{triggerWidth:"14.25rem",title:"Missing environment keys",description:(0,u.jsx)("p",{children:"You claimed this application but haven't set keys in your environment. Get them from the Clerk Dashboard."}),cta:{kind:"link",text:"Get API keys",href:({claimUrl:e})=>e}},completed:{triggerWidth:"10.5rem",title:"Your app is ready",description:({appName:e,instanceUrl:t})=>(0,u.jsxs)("p",{children:["Your application"," ",(0,u.jsx)("a",{href:t,target:"_blank",rel:"noopener noreferrer",children:e})," ","has been configured. You may now customize your settings in the Clerk dashboard."]}),cta:{kind:"action",text:"Dismiss",onClick:e=>{e?.().then(()=>{window.location.reload()})}}}};function b(e,t,r){return t?"completed":e?"claimed":r?"userCreated":"idle"}function y(e,t){let r=g[e],n="function"==typeof r.description?r.description({appName:t.appName,instanceUrl:t.instanceUrl}):r.description,i=r.cta,o="link"===i.kind?{kind:"link",text:i.text,href:"function"==typeof i.href?i.href({claimUrl:t.claimUrl,instanceUrl:t.instanceUrl}):i.href}:{kind:"action",text:i.text,onClick:()=>i.onClick(t.onDismiss)};return{state:e,triggerWidth:r.triggerWidth,title:r.title,description:n,cta:o}}function v(e){let t=(0,l.useId)(),r=(0,a.useRevalidateEnvironment)(),{isDragging:n,cornerStyle:i,containerRef:g,onPointerDown:v,preventClick:w,isInitialized:C}=(0,s.useDragToCorner)(),j=!!r.authConfig.claimedAt,k="function"==typeof e.onDismiss&&j,{isSignedIn:$}=(0,c.useUser)(),L=r.displayConfig.applicationName,U=(0,l.useMemo)(()=>{if(j)return e.copyKeysUrl;let t=new URL(e.claimUrl);return t.searchParams.append("return_url",window.location.href),t.href},[j,e.copyKeysUrl,e.claimUrl]),B=(0,l.useMemo)(()=>(function(e){try{return e()}catch{return"https://dashboard.clerk.com/last-active"}})(()=>{let t=(0,o.handleDashboardUrlParsing)(e.copyKeysUrl);return new URL(`${t.baseDomain}/apps/${t.appId}/instances/${t.instanceId}/user-authentication/email-phone-username`).href}),[e.copyKeysUrl]),[I,R]=(0,l.useState)(!0),S=b(j,k,!!$),E=(0,l.useMemo)(()=>y(S,{appName:L,instanceUrl:B,claimUrl:U,onDismiss:e.onDismiss}),[S,L,B,U,e.onDismiss]),D="link"===E.cta.kind?(0,u.jsx)("a",{href:E.cta.href,target:"_blank",rel:"noopener noreferrer",css:x,children:E.cta.text}):(0,u.jsx)("button",{type:"button",onClick:E.cta.onClick,css:x,children:E.cta.text});return(0,u.jsxs)("div",{ref:g,onPointerDown:I?void 0:v,style:{...i,opacity:C?void 0:0},"data-expanded":I,css:(0,d.css)`
        ${h};
        position: fixed;
        border-radius: ${I?"0.75rem":"2.5rem"};
        background-color: #1f1f1f;
        box-shadow:
          0px 0px 0px 0.5px #2f3037 inset,
          0px 1px 0px 0px rgba(255, 255, 255, 0.08) inset,
          0px 0px 0.8px 0.8px rgba(255, 255, 255, 0.2) inset,
          0px 0px 0px 0px rgba(255, 255, 255, 0.72),
          0px 16px 36px -6px rgba(0, 0, 0, 0.36),
          0px 6px 16px -2px rgba(0, 0, 0, 0.2);
        height: auto;
        isolation: isolate;
        transform: translateZ(0);
        backface-visibility: hidden;
        width: ${I?p:E.triggerWidth};
        cursor: ${n?"grabbing":I?"default":"grab"};
        touch-action: none;
        transition: ${n?"none":C?`width ${m(I)} ${f}, border-radius ${m(I)} cubic-bezier(0.2, 0, 0, 1)`:"none"};

        @media (prefers-reduced-motion: reduce) {
          transition: none;
        }
        &:has(button:focus-visible) {
          outline: 2px solid #6c47ff;
          outline-offset: 2px;
        }
        &::before {
          content: '';
          pointer-events: none;
          position: absolute;
          inset: 0;
          border-radius: inherit;
          background-image: linear-gradient(180deg, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 100%);
          opacity: 0.16;
          transition: opacity ${m(I)} ${f};

          @media (prefers-reduced-motion: reduce) {
            transition: none;
          }
        }
        &[data-expanded='true']::before,
        &:hover::before {
          opacity: 0.2;
        }
      `,children:[(0,u.jsxs)("button",{type:"button","aria-label":"Keyless prompt","aria-controls":t,"aria-expanded":I,onClick:()=>{w||R(e=>!e)},css:(0,d.css)`
          ${h};
          display: flex;
          align-items: center;
          width: 100%;
          border-radius: inherit;
          padding-inline: 0.75rem;
          gap: 0.25rem;
          height: 2.5rem;
          outline: none;
          cursor: pointer;
          user-select: none;
        `,children:[(0,u.jsxs)("svg",{css:(0,d.css)`
            width: 1rem;
            height: 1rem;
            flex-shrink: 0;
          `,fill:"none",viewBox:"0 0 128 128",children:[(0,u.jsx)("circle",{cx:"64",cy:"64",r:"20",fill:"#fff"}),(0,u.jsx)("path",{fill:"#fff",fillOpacity:".4",d:"M99.572 10.788c1.999 1.34 2.17 4.156.468 5.858L85.424 31.262c-1.32 1.32-3.37 1.53-5.033.678A35.846 35.846 0 0 0 64 28c-19.882 0-36 16.118-36 36a35.846 35.846 0 0 0 3.94 16.391c.851 1.663.643 3.712-.678 5.033L16.646 100.04c-1.702 1.702-4.519 1.531-5.858-.468C3.974 89.399 0 77.163 0 64 0 28.654 28.654 0 64 0c13.163 0 25.399 3.974 35.572 10.788Z"}),(0,u.jsx)("path",{fill:"#fff",d:"M100.04 111.354c1.702 1.702 1.531 4.519-.468 5.858C89.399 124.026 77.164 128 64 128c-13.164 0-25.399-3.974-35.572-10.788-2-1.339-2.17-4.156-.468-5.858l14.615-14.616c1.322-1.32 3.37-1.53 5.033-.678A35.847 35.847 0 0 0 64 100a35.846 35.846 0 0 0 16.392-3.94c1.662-.852 3.712-.643 5.032.678l14.616 14.616Z"})]}),(0,u.jsx)("span",{css:(0,d.css)`
            ${h};
            font-size: 0.875rem;
            font-weight: 500;
            color: #d9d9d9;
            white-space: nowrap;
          `,children:E.title}),(0,u.jsx)("svg",{css:(0,d.css)`
            width: 1rem;
            height: 1rem;
            flex-shrink: 0;
            color: #d9d9d9;
            margin-inline-start: auto;
            opacity: ${I?.5:0};
            transition: opacity ${m(I)} ease-out;

            @media (prefers-reduced-motion: reduce) {
              transition: none;
            }
            ${I&&(0,d.css)`
              button:hover & {
                opacity: 1;
              }
            `}
          `,viewBox:"0 0 16 16",fill:"none","aria-hidden":"true",xmlns:"http://www.w3.org/2000/svg",children:(0,u.jsx)("path",{d:"M3.75 8H12.25",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round"})})]}),(0,u.jsx)("div",{id:t,...!I&&{inert:""},css:(0,d.css)`
          ${h};
          display: grid;
          grid-template-rows: ${I?"1fr":"0fr"};
          transition: grid-template-rows ${m(I)} ${f};

          @media (prefers-reduced-motion: reduce) {
            transition: none;
          }
        `,children:(0,u.jsx)("div",{css:(0,d.css)`
            ${h};
            min-height: 0;
            overflow: hidden;
          `,children:(0,u.jsxs)("div",{css:(0,d.css)`
              ${h};
              width: ${p};
              padding-inline: 0.75rem;
              padding-block-end: 0.75rem;
              opacity: ${I?1:0};
              transition: opacity ${m(I)} ${f};

              @media (prefers-reduced-motion: reduce) {
                transition: none;
              }
            `,children:[(0,u.jsx)("div",{css:(0,d.css)`
                ${h};
                display: flex;
                flex-direction: column;
                gap: 0.5rem;
                & ul {
                  ${h};
                  list-style: disc;
                  padding-left: 1rem;
                }
                & p,
                & li {
                  ${h};
                  color: #b4b4b4;
                  font-size: 0.8125rem;
                  font-weight: 400;
                  line-height: 1rem;
                  text-wrap: pretty;
                }
                & a {
                  color: #fde047;
                  font-weight: 500;
                  outline: none;
                  text-decoration: underline;
                  &:focus-visible {
                    outline: 2px solid #6c47ff;
                    outline-offset: 2px;
                  }
                }
              `,children:E.description}),D]})})})]})}function w(e){return(0,u.jsx)(i.InternalThemeProvider,{children:(0,u.jsx)(v,{...e})})}},{"../../../styledSystem/InternalThemeProvider.js":"aiZZR","../shared.js":"2JCj5","./use-drag-to-corner.js":"5aG1d","./use-revalidate-environment.js":"jgs5h",react:"a8qhJ","@clerk/shared/react":"hObst","@emotion/react/jsx-runtime":"1XNeT","@emotion/react":"aNgYj","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"2JCj5":[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"ClerkLogoIcon",()=>d),n.export(r,"PromptContainer",()=>a),n.export(r,"PromptSuccessIcon",()=>c),n.export(r,"basePromptElementStyles",()=>l),n.export(r,"handleDashboardUrlParsing",()=>u);var i=e("../../customizables/index.js"),o=e("@emotion/react/jsx-runtime"),s=e("@emotion/react");function a({children:e,sx:t,...r}){return(0,o.jsx)(i.Flex,{sx:e=>[{borderRadius:"1.25rem",fontFamily:e.fonts.$main,background:"linear-gradient(180deg, rgba(255, 255, 255, 0.16) 0%, rgba(255, 255, 255, 0) 100%), #1f1f1f",boxShadow:"0px 0px 0px 0.5px #2F3037 inset, 0px 1px 0px 0px rgba(255, 255, 255, 0.08) inset, 0px 0px 0.8px 0.8px rgba(255, 255, 255, 0.20) inset, 0px 0px 0px 0px rgba(255, 255, 255, 0.72), 0px 16px 36px -6px rgba(0, 0, 0, 0.36), 0px 6px 16px -2px rgba(0, 0, 0, 0.20);"},t],...r,children:e})}let l=(0,s.css)`
  box-sizing: border-box;
  padding: 0;
  margin: 0;
  background: none;
  border: none;
  line-height: 1.5;
  font-family:
    -apple-system,
    BlinkMacSystemFont,
    avenir next,
    avenir,
    segoe ui,
    helvetica neue,
    helvetica,
    Cantarell,
    Ubuntu,
    roboto,
    noto,
    arial,
    sans-serif;
  text-decoration: none;
`;function c(e){return(0,o.jsx)("svg",{...e,viewBox:"0 0 16 17",fill:"none","aria-hidden":!0,xmlns:"http://www.w3.org/2000/svg",children:(0,o.jsxs)("g",{opacity:"0.88",children:[(0,o.jsx)("path",{d:"M13.8002 8.20039C13.8002 8.96206 13.6502 9.71627 13.3587 10.42C13.0672 11.1236 12.64 11.763 12.1014 12.3016C11.5628 12.8402 10.9234 13.2674 10.2198 13.5589C9.51607 13.8504 8.76186 14.0004 8.0002 14.0004C7.23853 14.0004 6.48432 13.8504 5.78063 13.5589C5.07694 13.2674 4.43756 12.8402 3.89898 12.3016C3.3604 11.763 2.93317 11.1236 2.64169 10.42C2.35022 9.71627 2.2002 8.96206 2.2002 8.20039C2.2002 6.66214 2.81126 5.18688 3.89898 4.09917C4.98669 3.01146 6.46194 2.40039 8.0002 2.40039C9.53845 2.40039 11.0137 3.01146 12.1014 4.09917C13.1891 5.18688 13.8002 6.66214 13.8002 8.20039Z",fill:"#22C543",fillOpacity:"0.16"}),(0,o.jsx)("path",{d:"M6.06686 8.68372L7.51686 10.1337L9.93353 6.75039M13.8002 8.20039C13.8002 8.96206 13.6502 9.71627 13.3587 10.42C13.0672 11.1236 12.64 11.763 12.1014 12.3016C11.5628 12.8402 10.9234 13.2674 10.2198 13.5589C9.51607 13.8504 8.76186 14.0004 8.0002 14.0004C7.23853 14.0004 6.48432 13.8504 5.78063 13.5589C5.07694 13.2674 4.43756 12.8402 3.89898 12.3016C3.3604 11.763 2.93317 11.1236 2.64169 10.42C2.35022 9.71627 2.2002 8.96206 2.2002 8.20039C2.2002 6.66214 2.81126 5.18688 3.89898 4.09917C4.98669 3.01146 6.46194 2.40039 8.0002 2.40039C9.53845 2.40039 11.0137 3.01146 12.1014 4.09917C13.1891 5.18688 13.8002 6.66214 13.8002 8.20039Z",stroke:"#22C543",strokeWidth:"1.2",strokeLinecap:"round",strokeLinejoin:"round"})]})})}function u(e){let t=new URL(e).href.match(/^https?:\/\/(.*?)\/apps\/app_(.+?)\/instances\/ins_(.+?)(?:\/.*)?$/);if(!t)throw Error("Invalid value Dashboard URL structure");return{baseDomain:`https://${t[1]}`,appId:`app_${t[2]}`,instanceId:`ins_${t[3]}`}}function d(){return(0,o.jsxs)("svg",{width:"1rem",height:"1.25rem",viewBox:"0 0 16 20",fill:"none","aria-hidden":!0,xmlns:"http://www.w3.org/2000/svg",children:[(0,o.jsxs)("g",{filter:"url(#filter0_i_438_501)",children:[(0,o.jsx)("path",{d:"M10.4766 9.99979C10.4766 11.3774 9.35978 12.4942 7.98215 12.4942C6.60452 12.4942 5.48773 11.3774 5.48773 9.99979C5.48773 8.62216 6.60452 7.50537 7.98215 7.50537C9.35978 7.50537 10.4766 8.62216 10.4766 9.99979Z",fill:"#BBBBBB"}),(0,o.jsx)("path",{d:"M12.4176 3.36236C12.6676 3.52972 12.6889 3.88187 12.4762 4.09457L10.6548 5.91595C10.4897 6.08107 10.2336 6.10714 10.0257 6.00071C9.41273 5.68684 8.71811 5.50976 7.98214 5.50976C5.5024 5.50976 3.49219 7.51998 3.49219 9.99972C3.49219 10.7357 3.66926 11.4303 3.98314 12.0433C4.08957 12.2511 4.06349 12.5073 3.89837 12.6724L2.07699 14.4938C1.86429 14.7065 1.51215 14.6851 1.34479 14.4352C0.495381 13.1666 0 11.641 0 9.99972C0 5.5913 3.57373 2.01758 7.98214 2.01758C9.62345 2.01758 11.1491 2.51296 12.4176 3.36236Z",fill:"#8F8F8F"}),(0,o.jsx)("path",{d:"M12.4762 15.905C12.6889 16.1177 12.6675 16.4698 12.4176 16.6372C11.149 17.4866 9.62342 17.982 7.9821 17.982C6.34078 17.982 4.81516 17.4866 3.54661 16.6372C3.29666 16.4698 3.27531 16.1177 3.48801 15.905L5.30938 14.0836C5.4745 13.9185 5.73066 13.8924 5.93851 13.9988C6.55149 14.3127 7.24612 14.4898 7.9821 14.4898C8.71808 14.4898 9.4127 14.3127 10.0257 13.9988C10.2335 13.8924 10.4897 13.9185 10.6548 14.0836L12.4762 15.905Z",fill:"#BBBBBB"})]}),(0,o.jsx)("defs",{children:(0,o.jsxs)("filter",{id:"filter0_i_438_501",x:"0",y:"1.86758",width:"12.6217",height:"16.1144",filterUnits:"userSpaceOnUse",colorInterpolationFilters:"sRGB",children:[(0,o.jsx)("feFlood",{floodOpacity:"0",result:"BackgroundImageFix"}),(0,o.jsx)("feBlend",{mode:"normal",in:"SourceGraphic",in2:"BackgroundImageFix",result:"shape"}),(0,o.jsx)("feColorMatrix",{in:"SourceAlpha",type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",result:"hardAlpha"}),(0,o.jsx)("feOffset",{dy:"-0.15"}),(0,o.jsx)("feGaussianBlur",{stdDeviation:"0.15"}),(0,o.jsx)("feComposite",{in2:"hardAlpha",operator:"arithmetic",k2:"-1",k3:"1"}),(0,o.jsx)("feColorMatrix",{type:"matrix",values:"0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"}),(0,o.jsx)("feBlend",{mode:"normal",in2:"shape",result:"effect1_innerShadow_438_501"})]})})]})}},{"../../customizables/index.js":"4yGSI","@emotion/react/jsx-runtime":"1XNeT","@emotion/react":"aNgYj","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],"5aG1d":[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"useDragToCorner",()=>p);var i=e("react");let o="clerk-keyless-prompt-corner",s="1.25rem",a="translate3d(0px, 0px, 0)",l={x:0,y:0},c=["top-left","top-right","bottom-left","bottom-right"];function u(e){if("undefined"!=typeof window)try{localStorage.setItem(o,e)}catch{}}function d(e){return e/1e3*.999/.0010000000000000009}function p(){let[e,t]=(0,i.useState)("bottom-right"),[r,n]=(0,i.useState)(!1),[p,f]=(0,i.useState)(!1),[h,m]=(0,i.useState)(!1),x=(0,i.useRef)(null);(0,i.useEffect)(()=>{if("undefined"==typeof window){m(!0);return}try{let e=localStorage.getItem(o);e&&c.includes(e)&&t(e)}catch{}finally{m(!0)}},[]);let g=(0,i.useRef)(null),b=(0,i.useRef)({state:"idle"}),y=(0,i.useRef)(null),v=(0,i.useRef)({x:0,y:0}),w=(0,i.useRef)({x:0,y:0}),C=(0,i.useRef)(0),j=(0,i.useRef)([]),k=(0,i.useRef)(null),$=(0,i.useCallback)(e=>{g.current&&(w.current=e,g.current.style.transform=`translate3d(${e.x}px, ${e.y}px, 0)`)},[]),L=(0,i.useCallback)(()=>{let t=g.current;if(!t)return{"top-left":l,"top-right":l,"bottom-left":l,"bottom-right":l};let r=k.current?.width??t.offsetWidth??0,n=k.current?.height??t.offsetHeight??0,i=window.innerWidth-document.documentElement.clientWidth;function o(e){let t=e.includes("right"),o=e.includes("bottom");return{x:t?window.innerWidth-i-20-r:20,y:o?window.innerHeight-20-n:20}}let s=o(e);function a(e){let t=o(e);return{x:t.x-s.x,y:t.y-s.y}}return{"top-left":a("top-left"),"top-right":a("top-right"),"bottom-left":a("bottom-left"),"bottom-right":a("bottom-right")}},[e]),U=(0,i.useCallback)(r=>{let n=g.current;if(!n)return;let i=r.translation.x-w.current.x,o=r.translation.y-w.current.y;if(.5>Math.sqrt(i*i+o*o)){u(r.corner),w.current=l,n.style.transition="",n.style.transform=a,b.current={state:"idle"},f(!1);return}let s=i=>{"transform"===i.propertyName&&(n.removeEventListener("transitionend",s),u(r.corner),r.corner===e?(w.current=l,n.style.transition="",n.style.transform=a,b.current={state:"idle"},f(!1)):(b.current={state:"animating"},x.current=r.corner,t(r.corner)))};n.style.transition="transform 350ms cubic-bezier(0.34, 1.2, 0.64, 1)",n.addEventListener("transitionend",s),$(r.translation)},[$,e]),B=(0,i.useCallback)(()=>{"drag"===b.current.state?(g.current?.releasePointerCapture(b.current.pointerId),b.current={state:"animating"}):b.current={state:"idle"},y.current&&(y.current(),y.current=null),j.current=[],n(!1),k.current=null,g.current?.classList.remove("dev-tools-grabbing"),document.body.style.removeProperty("user-select"),document.body.style.removeProperty("-webkit-user-select")},[]);(0,i.useLayoutEffect)(()=>{if(x.current===e){let e=g.current;e&&"animating"===b.current.state&&(w.current=l,e.style.transition="",e.style.transform=a,b.current={state:"idle"},f(!1),x.current=null)}},[e]),(0,i.useLayoutEffect)(()=>()=>{B()},[B]);let I=(0,i.useCallback)(e=>{let t=e.target;if("A"===t.tagName||t.closest("a")||0!==e.button)return;let r=g.current;if(!r)return;k.current={width:r.offsetWidth,height:r.offsetHeight},v.current={x:e.clientX,y:e.clientY};let i=r.style.transform;if(i&&"none"!==i&&i!==a){let e=i.match(/translate3d\(([^,]+)px,\s*([^,]+)px/);e&&(w.current={x:parseFloat(e[1])||0,y:parseFloat(e[2])||0})}else w.current=l;b.current={state:"press"},j.current=[],C.current=Date.now();let o=e=>{if("press"===b.current.state){let t=e.clientX-v.current.x,i=e.clientY-v.current.y;if(5>Math.sqrt(t*t+i*i))return;b.current={state:"drag",pointerId:e.pointerId};try{r.setPointerCapture(e.pointerId)}catch{}r.style.transition="none",r.classList.add("dev-tools-grabbing"),document.body.style.userSelect="none",document.body.style.webkitUserSelect="none",n(!0),$({x:w.current.x+t,y:w.current.y+i}),v.current={x:e.clientX,y:e.clientY};return}if("drag"!==b.current.state)return;let t={x:e.clientX,y:e.clientY},i=t.x-v.current.x,o=t.y-v.current.y;v.current=t,$({x:w.current.x+i,y:w.current.y+o});let s=Date.now();s-C.current>=10&&(j.current=[...j.current.slice(-4),{position:t,timestamp:s}],C.current=s)},s=()=>{if("drag"===b.current.state){let e=function(e){if(e.length<2)return l;let t=e[0],r=e[e.length-1],n=r.timestamp-t.timestamp;return 0===n?l:{x:(r.position.x-t.position.x)/n*1e3,y:(r.position.y-t.position.y)/n*1e3}}(j.current),t=L();if(B(),!g.current)return;let r=function(e,t){let r="bottom-right",n=1/0;for(let[i,o]of Object.entries(t)){let t=e.x-o.x,s=e.y-o.y,a=Math.sqrt(t*t+s*s);a<n&&(n=a,r=i)}return r}({x:w.current.x+d(e.x),y:w.current.y+d(e.y)},t),n=t[r];f(!0),U({corner:r,translation:n})}else B()},c=e=>{let t=e.target,r="BUTTON"===t.tagName||t.closest("button"),n="A"===t.tagName||t.closest("a");"animating"!==b.current.state||r||n||(e.preventDefault(),e.stopPropagation())};window.addEventListener("pointermove",o),window.addEventListener("pointerup",s,{once:!0}),window.addEventListener("pointercancel",B,{once:!0}),r.addEventListener("click",c),y.current&&y.current(),y.current=()=>{window.removeEventListener("pointermove",o),window.removeEventListener("pointerup",s),window.removeEventListener("pointercancel",B),r.removeEventListener("click",c)}},[B,$,U,L]);return{corner:e,isDragging:r,cornerStyle:function(e){switch(e){case"top-left":return{top:s,left:s};case"top-right":return{top:s,right:s};case"bottom-left":return{bottom:s,left:s};case"bottom-right":return{bottom:s,right:s}}}(e),containerRef:g,onPointerDown:I,preventClick:p,isInitialized:h}}},{react:"a8qhJ","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}],jgs5h:[function(e,t,r){var n=e("@parcel/transformer-js/src/esmodule-helpers.js");n.defineInteropFlag(r),n.export(r,"useRevalidateEnvironment",()=>a);var i=e("../../../contexts/EnvironmentContext.js"),o=e("react"),s=e("@clerk/shared/react");function a(){let e=(0,s.useClerk)(),t=(0,o.useRef)(Date.now()),[,r]=(0,o.useReducer)(e=>e+1,0);return(0,o.useEffect)(()=>{let n=new AbortController;return window.addEventListener("focus",async()=>{let i=e.__internal_environment;if(i){if(null!==i.authConfig.claimedAt)return n.abort();if(!(Date.now()<t.current+1e4)&&"visible"===document.visibilityState)for(let e=0;e<2;e++){let{authConfig:{claimedAt:e}}=await i.fetch();if(t.current=Date.now(),null!==e){r();break}}}},{signal:n.signal}),()=>{n.abort()}},[]),(0,i.useEnvironment)()}},{"../../../contexts/EnvironmentContext.js":"eQ6Zj",react:"a8qhJ","@clerk/shared/react":"hObst","@parcel/transformer-js/src/esmodule-helpers.js":"fRZO2"}]},[],null,"parcelRequire56c9"),globalThis.define=t;